<?php


class Users extends Model {

	function __construct() {
		parent::__construct('users');
    }
    
    function SetPass($text) {
		$key = \Base::instance()->get('APP_KEY');
		$crypt = new \Helper\Crypt($key);
		$this->set('password',$crypt->encrypt($text));
		return $this;
    }
    
}