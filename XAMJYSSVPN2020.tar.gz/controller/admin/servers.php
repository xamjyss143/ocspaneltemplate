<?php 

namespace Admin;

class Servers extends \Home {

	use \Helper\Servers;

	protected
		$server;

	function beforeRoute($f3) {
		parent::beforeRoute($f3);
		if ( $this->me->isAdmin()) {
             $f3->reroute('/home/admin/server'); 
        $this->server = new \Server;
        }
        else {
             $f3->reroute('/home/settings');
        $this->server = new \Server;
        }
	}

	function All($f3) {
		$server = $this->server->find();
		$f3->set('servers',$server);
		$f3->set('subcontent','setting.html');
	}

	function Id($f3) {
		$server = $this->loadServer();
		$f3->set('server',$server);
		$f3->set('subcontent','setting.html');
	}

	
// "create\:$svr['user']\:$svr['pass']\:$svr['uid']\:$svr['gid']\:$svr['real']\:$svr['home']\:$svr['shell']\:$svr['min']\:$svr['max']\:$svr['warn']\:$svr['inactive']\:$svr['expire']";
}