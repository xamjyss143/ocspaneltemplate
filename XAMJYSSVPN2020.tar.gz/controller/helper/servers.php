<?php

namespace Helper;

trait Servers {

	function loadServers() {
		$f3 = \Base::instance();
		$server = $this->server;
		if ($f3->exists('PARAMS.id',$id)) {
			if ($this->me->isAdmin()) {
				$server->id($id);
				$server->reroute('/home/setting');
			} else {
				$server->load(array($id));
				$server->reroute('/home/settings');
			}
		}
		return $server;
	}

}