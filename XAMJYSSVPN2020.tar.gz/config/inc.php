<?php die();
[globals]
DEBUG=0
AUTOLOAD="controller/;model/"
UI="view/"
APP_KEY="844db372d939c5b4a9ca7eb61e171e7fae1dfdd95e9cf5b77b296ba078c22f31"
DB_SET="mysql:host=localhost;port=3306;dbname=xamjyssvpn"
DB_USER="root"
DB_PASS="may261999"
?>