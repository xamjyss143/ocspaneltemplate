<?php 

namespace Member;

class Serverz extends \Home {

	use \Helper\Serverz;

	protected
		$server;

	function beforeRoute($f3) {
		parent::beforeRoute($f3);
		if ( $this->me->isAdmin()) $f3->reroute('/home/admin/configs');
		$this->server = new \Server;
	}

	function All($f3) {
		$server = $this->server->find(array());
		$f3->set('servers',$server);
		$f3->set('subcontent','member/configs.html');
	}
}