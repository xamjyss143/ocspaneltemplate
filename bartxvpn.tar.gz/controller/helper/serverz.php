<?php

namespace Helper;

trait Serverz {

	function loadServer() {
		$f3 = \Base::instance();
		$server = $this->server;
		if ($f3->exists('PARAMS.id',$id)) {
			if ($this->me->isAdmin()) {
				$server->id($id);
				$server->reroute('/home/admin/configs');
			} else {
				$server->load(array('id=?',$id));
				$server->reroute('/home/member/configs');
			}
		}
		return $server;
	}

}