<?php 

namespace Member;

class Configs extends \Home {

	use \Helper\Configs;

	protected
		$server;

	function beforeRoute($f3) {
		parent::beforeRoute($f3);
		if ( $this->me->isAdmin()) $f3->reroute('/home/admin/server/');
		$this->server = new \Server;
	}

	function All($f3) {
		$server = $this->server->find(array('active=1'));
		$f3->set('server',$server);
		$f3->set('subcontent','member/configs.html');
	}

	function Id($f3) {
		$server = $this->loadServer();
		$f3->set('server',$server);
		$f3->set('subcontent','member/configs.html');
	}
}