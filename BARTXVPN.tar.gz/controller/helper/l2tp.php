<?php

namespace Helper;

trait L2tp {

	function loadServer() {
		$f3 = \Base::instance();
		$server = $this->server;
		if ($f3->exists('PARAMS.id',$id)) {
			if ($this->me->isAdmin()) {
				$server->id($id);
				$server->reroute('/home/admin/l2tp');
			} else {
				$server->load(array('id=?',$id));
				$server->reroute('/home/member/l2tp');
			}
		}
		return $server;
	}

}