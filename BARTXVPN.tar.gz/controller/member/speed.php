<?php 

namespace Member;

class Speed extends \Home {

	use \Helper\Speed;

	protected
		$server;

	function beforeRoute($f3) {
		parent::beforeRoute($f3);
		if ( $this->me->isAdmin()) $f3->reroute('/home/admin/speedtest');
		$this->server = new \Server;
	}

	function All($f3) {
		$server = $this->server->find(array());
		$f3->set('servers',$server);
		$f3->set('subcontent','member/speedtest.html');
	}
}