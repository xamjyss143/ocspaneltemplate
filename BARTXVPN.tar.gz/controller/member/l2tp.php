<?php 

namespace Member;

class L2tp extends \Home {

	use \Helper\L2tp;

	protected
		$server;

	function beforeRoute($f3) {
		parent::beforeRoute($f3);
		if ( $this->me->isAdmin()) $f3->reroute('/home/admin/l2tp');
		$this->server = new \Server;
	}

	function All($f3) {
		$server = $this->server->find(array());
		$f3->set('servers',$server);
		$f3->set('subcontent','member/l2tp.html');
	}
}